"use strict";
// Ejercicio D1S1.1.1
console.log("Hola");
// Ejercicio D1S1.1.2
// Ejercicio D1S2.1.1
// Ejercicio D1S2.1.2
// Ejercicio D1S2.2.1
// Ejercicio D1S2.2.2
