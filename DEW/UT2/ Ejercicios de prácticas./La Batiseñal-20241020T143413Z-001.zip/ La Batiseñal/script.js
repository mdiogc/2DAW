function activarBatiseñal() {
    document.body.style.backgroundImage = "url('img.jpg')";}