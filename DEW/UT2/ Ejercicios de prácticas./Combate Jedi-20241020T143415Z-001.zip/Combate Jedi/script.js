// Clase Jedi
class Jedi {
    constructor(nombre, nivelFuerza, arma) {
      this.nombre = nombre;
      this.nivelFuerza = nivelFuerza;
      this.arma = arma;
    }
  }

  // Clase Sith
  class Sith {
    constructor(nombre, nivelFuerza, arma) {
      this.nombre = nombre;
      this.nivelFuerza = nivelFuerza;
      this.arma = arma;
    }
  }

  // Instanciación de un Jedi y un Sith
  const jedi = new Jedi('Luke Skywalker', 95, 'Sable de luz verde');
  const sith = new Sith('Darth Vader',100, 'Sable de luz rojo');

  // Función que simula el combate
  function simularCombate() {
    let resultado = '';

    if (jedi.nivelFuerza > sith.nivelFuerza) {
      resultado = `¡${jedi.nombre} gana el combate con su ${jedi.arma}!`;
    } else if (sith.nivelFuerza > jedi.nivelFuerza) {
      resultado = `¡${sith.nombre} gana el combate con su ${sith.arma}!`;
    } else {
      resultado = 'El combate termina en empate. Ambos tienen la misma fuerza.';
    }

    // Muestra el resultado en el DOM
    document.getElementById('resultado').textContent = resultado;
  }