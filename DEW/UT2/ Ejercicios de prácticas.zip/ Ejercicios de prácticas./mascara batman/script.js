document.getElementById('toggleBtn').onclick = function() {
    const batmanImg = document.getElementById('batman');
    batmanImg.style.display = (batmanImg.style.display === "none") ? "block" : "none";
};
